# neural-network-test
this is just a test of a simple neural network, no hidden layers just inputs and an output. also please remember this is a test.
i know that its just setting the variable theoutputvaluea without using the outputvalue variable in the function because it doesn't work, i don't know why. ill
fix it sometime.
